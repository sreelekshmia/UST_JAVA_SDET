package urban;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefenition {
	WebDriver d;
	@Then("Navigate to Browser")
	
	public void navigate_to_browser() throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Jerome Mathew\\Downloads\\chromedriver_win32\\chromedriver.exe");
		 d=new ChromeDriver();
		d.navigate().to("https://www.urbanladder.com/");
		//d.findElement(By.linkText("Log-in")).click();
		
		d.manage().window().maximize();
		Thread.sleep(2000);
	}
	
	@When("login")
	public void login() throws InterruptedException {
		d.findElement(By.xpath("/html/body/div[1]/header/div[1]/div/section[3]/ul/li[2]/span")).click();
		Thread.sleep(2000);
		d.findElement(By.partialLinkText("Log In")).click();
		Thread.sleep(10000);
		d.findElement(By.xpath("/html/body/div[6]/div/div[1]/div/div[2]/div[3]/form/div/input")).sendKeys( "harimurali007@gmail.com");
		d.findElement(By.xpath("/html/body/div[6]/div/div[1]/div/div[2]/div[3]/form/div/div/div/input")). sendKeys("harimurali007");
		d.findElement(By.id("ul_site_login")).click();
	}
	@When("Bed")
	public void Bed() throws InterruptedException{
		d.findElement(By.xpath("/html/body/div[1]/header/div[2]/div/nav/div/ul/li[3]/span")).click();
		String s = d.findElement(By.partialLinkText("Beds")).getText();
		/*System.out.println(s);
		Assert.assertEquals(s,"Beds");*/
	}
	@When("mattresses")
	public void mattresses() throws InterruptedException{
		d.findElement(By.xpath("/html/body/div[1]/header/div[2]/div/nav/div/ul/li[3]/span")).click();
		String s = d.findElement(By.partialLinkText("Mattresses")).getText();
		/*System.out.println(s);
		Assert.assertEquals(s,"Mattresses");*/
		
	}
	@When("Storage")
	public void Storage() throws InterruptedException{
		d.findElement(By.xpath("/html/body/div[1]/header/div[2]/div/nav/div/ul/li[3]/span")).click();
		String s = d.findElement(By.partialLinkText("Storage & Accessories")).getText();
		System.out.println(s);
		Assert.assertEquals(s,"Storage & Accessories");
		
	}
	@When("kids")
	public void kids() throws InterruptedException{
		d.findElement(By.xpath("/html/body/div[1]/header/div[2]/div/nav/div/ul/li[3]/span")).click();
		String s = d.findElement(By.partialLinkText("Kids Bedroom")).getText();
		System.out.println(s);
		Assert.assertEquals(s,"Kids Bedroom");
		
	}
	@When("doublebeds")
	public void doublebeds() throws InterruptedException{
			d.findElement(By.xpath("/html/body/div[1]/header/div[2]/div/nav/div/ul/li[3]/span")).click();
			d.findElement(By.partialLinkText("Double Beds")).click();
			d.findElement(By.xpath("/html/body/div[2]/div[2]/div[3]/div[2]/div[1]/div/form/div[1]/div/div/ul/li[1]/div[1]")).click();
			d.findElement(By.xpath("/html/body/div[2]/div[2]/div[3]/div[2]/div[1]/div/form/div[1]/div/div/ul/li[1]/div[2]/div/div/ul/li[2]/div[1]/label/input")).click();
			Thread.sleep(1000);
			d.findElement(By.xpath("/html/body/div[2]/div[2]/div[3]/div[2]/div[1]/div/form/div[1]/div/div/ul/li[3]/div[1]")).click();
			d.findElement(By.xpath("/html/body/div[2]/div[2]/div[3]/div[2]/div[1]/div/form/div[1]/div/div/ul/li[3]/div[2]/div/div/div[1]/ul/li[1]/input")).click();
			//JavascriptExecutor js = (JavascriptExecutor) d;
			//js.executeScript("window.scrollBy(0,350)");
			
			
	}
	/*@When("back")
	public void back() throws InterruptedException{
		d.navigate().back();
		d.navigate().back();
	}*/
}
